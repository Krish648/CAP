package com.cg.mobilebilling.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class PlanController {
	@Autowired
	BillingServices billingServices;
	
	@RequestMapping("/getAllPlanDetails")
	public ModelAndView getPlanAllDetails() throws BillingServicesDownException {
		List<Plan> plans = billingServices.getPlanAllDetails();
			return new ModelAndView("getAllPlanDetailsPage","plans",plans);
	}
	
	@RequestMapping("/changePlanDetails")
	public ModelAndView changePlanDetails(@RequestParam int customerID,@RequestParam long mobileNo, @RequestParam int planID) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
			boolean status = billingServices.changePlan(customerID, mobileNo, planID);
			if(status)
				return new ModelAndView("planChangeSuccessPage");
			else
				return new ModelAndView("changePlanPage");
	}

	@RequestMapping("/postpaidAccountPlanDetails")
	public ModelAndView getpostpaidAccountPlanDetails(@RequestParam int customerID,@RequestParam long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
			Plan plan = billingServices.getCustomerPostPaidAccountPlanDetails(customerID, mobileNo);
			return new ModelAndView("postpaidAccountPlanDetailsPage","plan",plan);
	}

}
