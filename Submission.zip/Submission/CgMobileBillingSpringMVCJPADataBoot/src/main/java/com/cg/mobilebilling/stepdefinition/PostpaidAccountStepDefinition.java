package com.cg.mobilebilling.stepdefinition;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PostpaidAccountStepDefinition {
	@Given("^User is on postpaid account change plan page$")
	public void user_is_on_postpaid_account_change_plan_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters <customerID>, <mobileNo> and <planID> into which the plan should be changed$")
	public void user_enters_customerID_mobileNo_and_planID_into_which_the_plan_should_be_changed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Clicks on postpaid account change plan submit button$")
	public void clicks_on_postpaid_account_change_plan_submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Verify whether given <cusomterID>, <mobileNo> and <planID> are valid$")
	public void verify_whether_given_cusomterID_mobileNo_and_planID_are_valid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Change plan for that particular <postpaidAccount>$")
	public void change_plan_for_that_particular_postpaidAccount() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
