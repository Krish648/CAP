package com.cg.mobilebilling.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgMobileBillingSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgMobileBillingSpringBootApplication.class, args);
	}
}
