package com.cg.mobilebilling.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class BillController {
	@Autowired
	BillingServices billingServices;
	
	@RequestMapping("/mobileBillGeneration")
	public ModelAndView generateMonthlyMobileBill(@RequestParam int customerID,@RequestParam long mobileNo,@RequestParam String billMonth,@RequestParam int noOfLocalSMS,
			@RequestParam int noOfStdSMS,@RequestParam int noOfLocalCalls,@RequestParam int noOfStdCalls,@RequestParam int internetDataUsageUnits) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		Bill bill=billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits);
		return new ModelAndView("mobileBillPage","bill",bill);
	}
	
	@RequestMapping("/mobileBillDetails")
	public ModelAndView getmobileBillDetails(@RequestParam int customerID,@RequestParam long mobileNo,@RequestParam String billMonth) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, BillingServicesDownException  {
			Bill bill = billingServices.getMobileBillDetails(customerID, mobileNo, billMonth);
			return new ModelAndView("mobileBillDetailsPage","bill",bill);
	}

	@RequestMapping("/getAllBillDetails")
	public ModelAndView getmobileAllBillDetails(@RequestParam int customerID,@RequestParam long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException {
		List<Bill> bills = billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
			return new ModelAndView("mobileAllBillDetailsPage","bills",bills);
	}


}
