var message:string="Hello To All Welcome To JavaScript"
console.log(message)