var message = "Hello To All Welcome To JavaScript";
console.log(message);
