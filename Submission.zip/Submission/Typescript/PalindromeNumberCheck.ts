
var  number:number;
var digits[]:Array;




constructor()

palindromeCheck(){


}