package com.cg.banking.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
@Controller
public class URIController {
	Account account;
	Transaction transaction;
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping("/openAccount")
	public String getRegisterPage() {
		return "openAccountPage";
	}
	@RequestMapping("/deposit")
	public String getDepositAmountPage() {
		return "depositAmountPage";
	}
	@RequestMapping("/withdraw")
	public String getWithdrawAmountPage() {
		return "withdrawAmountPage";
	}
	@RequestMapping("/fundsTransfer")
	public String getFundsTransferPage() {
		return "fundsTransferPage";
	}
	@RequestMapping("/getAccountDetails")
	public String getAccountDetailsPage() {
		return "getAccountDetailsPage";
	}
	@RequestMapping("/getAccountAllTransactionDetails")
	public String getAccountAllTransactionDetailsPage() {
		return "getAccountAllTransactionDetailsPage";
	}
	@ModelAttribute
	public Account getAccount() {
		account=new Account();
		return account;
	}
	@ModelAttribute
	public Transaction getTransaction() {
		transaction=new Transaction();
		return transaction;
	}
}