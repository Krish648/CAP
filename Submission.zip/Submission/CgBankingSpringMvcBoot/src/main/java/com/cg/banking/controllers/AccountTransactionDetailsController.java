package com.cg.banking.controllers;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServices;
@Controller
public class AccountTransactionDetailsController {
	@Autowired
	private BankingServices bankingServices;
	@RequestMapping("/displayAccountAllTransactionDetails")
	public ModelAndView DepositAmount(@RequestParam("accountNo")int accountNo) {
		List<Transaction> transactions=bankingServices.getAccountAllTransaction(accountNo);
		return new ModelAndView("displayAccountAllTransactionDetailsPage","transactions",transactions);
	}
}
