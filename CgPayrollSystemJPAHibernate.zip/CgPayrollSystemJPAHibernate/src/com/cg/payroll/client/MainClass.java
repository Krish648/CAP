package com.cg.payroll.client;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

import java.sql.Driver;
import java.util.Scanner;


public class MainClass {
	public static void main(String[] args) {
		PayrollServices payrollServices = new PayrollServicesImpl();
		int num;
		Associate temp=new Associate();
		BankDetails temp1=new BankDetails();
		Salary temp2=new Salary();
		System.out.println("Net Salary and Tax Deductions Calculation");
		System.out.println("Accept Associate Details - 1");
		System.out.println("Calculate Net Salary - 2");
		System.out.println("Get Associate Details - 3");
		System.out.println("Get All Associate Details - 4");
		System.out.println("Choose a number to proceed.");
		Scanner in = new Scanner(System.in);
		num = in.nextInt();
		
		
		
	}
	
}
