package com.cg.project.services;

public class GreetingServicesImpl2 implements GreetingServices {
	
	@Override
	public void greetUser(String name) {
		System.out.println("Hi "+ name);
	}

}
