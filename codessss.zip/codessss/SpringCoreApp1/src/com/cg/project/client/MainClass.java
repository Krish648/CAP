package com.cg.project.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.project.services.GreetingServices;
import com.cg.project.services.GreetingServicesImpl2;

public class MainClass {

	public static void main(String[] args) {
		
	/*	GreetingServices greetingServices = new GreetingServicesImpl2();
		greetingServices.greetUser("KRISHNA");*/
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("projectBeans.xml");
		
		GreetingServices greetingServices = (GreetingServices) context.getBean("greetingServices");
		
		greetingServices.greetUser("Krishna");

	}

}
