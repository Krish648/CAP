package com.cg.payroll.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exception.PayrollServicesDownException;

@Component(value="payrollServices")
public class PayrollServicesImpl implements PayrollServices {

	@Autowired
	private AssociateDAO associateDAO;

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) throws PayrollServicesDownException {
		Associate associate = new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new BankDetails(accountNumber, bankName, ifscCode), new Salary(basicSalary, epf, companyPf)); 

		associate=associateDAO.save(associate);

		return associate.getAssociateID();
	}

	@Override
	public int calculateNetSalary(int associateId)
	{
		Associate associate = associateDAO.findById(associateId).get();
		Salary NetSalaryAftertaxes = new Salary();
		NetSalaryAftertaxes=associate.getSalary();
		int tax=0;

		if(associate.getYearlyInvestmentUnder80C()>150000)
			associate.setYearlyInvestmentUnder80C(150000);
		if(associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()<250000)
		{
			NetSalaryAftertaxes.setNetSalary(associate.getSalary().getGrossSalary());
		}
		else if(associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()>250000 && associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()<500000)
		{
			tax=(int) (0.05*(associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()));
			NetSalaryAftertaxes.setNetSalary(associate.getSalary().getGrossSalary()-tax);
		}
		else if(associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()>500000 && associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()<1000000)
		{
			tax=(int) (0.20*(associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()-500000)+(12500));
			NetSalaryAftertaxes.setNetSalary(associate.getSalary().getGrossSalary()-tax);
		}
		else{
			tax=(int) (0.30*(associate.getSalary().getGrossSalary()-associate.getYearlyInvestmentUnder80C()-1000000)+(112500));
			NetSalaryAftertaxes.setNetSalary(associate.getSalary().getGrossSalary()-tax);
		}

		NetSalaryAftertaxes.setMonthlyTax(tax);
		associate.setSalary(NetSalaryAftertaxes);
		return 0;
	}

	private Object getGrossSalary() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Associate getAssociateDetails(int associateId){
		Associate associate =  associateDAO.findById(associateId).get();
		return associate;
	}

	@Override
	public List<Associate> getAllAssociatesDetails()  {
		return associateDAO.findAll();
	}


}