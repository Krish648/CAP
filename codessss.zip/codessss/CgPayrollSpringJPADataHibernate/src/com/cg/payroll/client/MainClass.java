package com.cg.payroll.client;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class MainClass {
	public static void main(String[] args) {
		try {

			ApplicationContext context = new ClassPathXmlApplicationContext("projectbeans.xml");
			//	PayrollServices payrollServices = (PayrollServices)ApplicationContext.getBean(payrollServices)

			PayrollServices payrollServices =(PayrollServices)context.getBean("payrollServices");
			System.out.println(payrollServices.acceptAssociateDetails("Krishna", "Kumar", "k@cg.com", "IT", "Analyst", "ADFG1324", 150000, 100000, 100, 100, 635241897, "SBI", "SBIN0021324"));
		}catch(PayrollServicesDownException e) {
			e.printStackTrace();
		}

	}
}		










/*AssociateDAO dao=new AssociateDAOImpl();
		PayrollServices services=new PayrollServicesImpl();
		BankDetails bankdetails=new BankDetails(101, "KMB", "asdf123");
		Salary salary=new Salary(10000,1000,1000);
		Associate associate=new Associate(10000,"charan","kothuri","chemical","S.Con","adsf132","asdfadsf@gmail.com",bankdetails,salary);
 */
//System.out.println(payrollServices.acceptAssociateDetails("Krishna", "Kumar", "kk@gmail.com", "IT", "Sr.Analyst", "PAN1324", "150000", "6000000", "10000", "10000", "6263108540", "CITI", "CITI005"));

//System.out.println(payrollServices.acceptAssociateDetails("K", "Ku", "@cg.com", "it", "manager", pancard, yearlyInvestmentUnder80C, basicSalary, epf, companyPf, accountNumber, bankName, ifscCode)
/*services.calculateNetSalary(associateId);
		associate=services.getAssociateDetails(associateId);
		System.out.println(associate);
 */

//System.out.println(dao.findOne(1));
//System.out.println(dao.findAll());



/*		PayrollServices payrollServices = new PayrollServicesImpl();
		int num;
		Associate temp=new Associate();
		BankDetails temp1=new BankDetails();

		package com.cg.payroll.client;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.service.PayrollServices;
import com.cg.payroll.service.PayrollServicesImpl;


public class MainClass {
	public static void main(String[] args) throws PayrollServicesDownException, AssociateDetailsNotFoundException {
		AssociateDAO dao=new AssociateDAOImpl();
		PayrollServices services=new PayrollServicesImpl();
		BankDetails bankdetails=new BankDetails(101, "KMB", "asdf123");
		Salary salary=new Salary(10000,1000,1000);
		Associate associate=new Associate(10000,"charan","kothuri","chemical","S.Con","adsf132","asdfadsf@gmail.com",bankdetails,salary);
		/*int associateId=services.acceptAssociateDetails(10000,"charan","kothuri","chemical","S.Con","adsf132","asdfadsf@gmail.com",bankdetails,salary);
		System.out.println("Associate Id="+associateId);
		services.calculateNetSalary(associateId);
		associate=services.getAssociateDetails(associateId);
		System.out.println(associate);*/
//System.out.println(dao.findOne(1));
//System.out.println(dao.findAll());


