/*package com.cg.payroll.client;

import com.cg.payroll.util.ConnectionProvider;

public class ConncetionTest {

	public static void main(String[] args) {

		if(ConnectionProvider.getDBConnection()!=null)
			System.out.println("Connection Open");
		else
			System.out.println("Error in Connection");

		SInce connection isopen now. we can delet this file.
	}

}
*/