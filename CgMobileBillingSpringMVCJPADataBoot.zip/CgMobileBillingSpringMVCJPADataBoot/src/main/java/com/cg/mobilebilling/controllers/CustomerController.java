package com.cg.mobilebilling.controllers;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
@Controller
public class CustomerController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/customerRegistration")
	public ModelAndView acceptCustomerDetails(@ ModelAttribute Customer customer,BindingResult bindingResult) throws BillingServicesDownException{
			customer=billingServices.acceptCustomerDetails(customer);
			return new ModelAndView("customerRegistrationSuccessPage","customer",customer);
	}	
	
	@RequestMapping("/deleteCustomerSuccessful")
	public ModelAndView deleteCustomer(@RequestParam int customerID) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
			billingServices.deleteCustomer(customerID);
			return new ModelAndView("deleteCustomerSuccessfulPage","customerID",customerID);
	}

	@RequestMapping("/getCustomer")
	public ModelAndView getCustomerDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException, BillingServicesDownException{
		Customer customer = billingServices.getCustomerDetails(customerID);
			return new ModelAndView("customerDetailsPage","customer",customer);
	}

	@RequestMapping("/getAllCustomerDetails")
	public ModelAndView getAllCustomerDetails() throws BillingServicesDownException  {
		List<Customer> customers = billingServices.getAllCustomerDetails();
			return new ModelAndView("getAllCustomerDetailsPage","customers",customers);
	}

	
}