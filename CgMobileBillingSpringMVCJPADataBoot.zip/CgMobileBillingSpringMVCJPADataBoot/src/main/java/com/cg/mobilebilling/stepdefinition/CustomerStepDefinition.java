package com.cg.mobilebilling.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CustomerStepDefinition {
	@Given("^User is on add customer page$")
	public void user_is_on_add_customer_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^User enters customer details$")
	public void user_enters_customer_details() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^Clicks add customer submit button$")
	public void clicks_add_customer_submit_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^Check whether entered details are valid$")
	public void check_whether_entered_details_are_valid() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^Entered details are not empty$")
	public void entered_details_are_not_empty() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^Add new <Customer> to database$")
	public void add_new_Customer_to_database() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Given("^User is on remove customer page$")
	public void user_is_on_remove_customer_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^User enters customerID$")
	public void user_enters_customerID() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^Clicks remove customer submit button$")
	public void clicks_remove_customer_submit_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^<Customer> with entered customerID is removed from database$")
	public void customer_with_entered_customerID_is_removed_from_database() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Given("^User is on display customer page$")
	public void user_is_on_display_customer_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^Clicks view customer submit button$")
	public void clicks_view_customer_submit_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^<Customer> details with entered customerID is displayed from database$")
	public void customer_details_with_entered_customerID_is_displayed_from_database() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

}
