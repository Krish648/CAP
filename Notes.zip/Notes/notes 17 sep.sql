diff bw AND and BETWEEN
eg:

select salary from SalaryTable where salary > 10000 AND salary < 100000  ==>> column name is used twice; when condition is used on same column name.

SELECT salary from SAlaryTable where salary between 10000 and 100000 	==>> column name is used once.

// between condition fails/is not used if more than 1 condition is used or  more than 1 column names.is used for different condition.//


DIFF bw IN and OR 
select * from Associate 
		WHERE firstName = 'Alpha' or firstName = 'Bravo' or firstName = 'Charlie';
		
SELECT * from Associate 
		WHERE firstName IN('Alpha','Bravo','Charlie');

// IN operator reduces the column name to repeated if condition is used on same column.


SELECT * FROM Salary 
		where basicSalary BETWEEN 10000  AND 150000;
SELECT firstName from  Associate JOIN Salary
		where monthlyTax = 3000;
