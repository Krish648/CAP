package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String associateId=request.getParameter("associateId");
		String password=request.getParameter("password");
		String[] Hobbies=request.getParameterValues("Hobbies");
		
		PrintWriter out= response.getWriter();

		
		out.print("<html><title>Sign Up </title><body>");
		
		/*out.println("<form>AssociateId: <input type=text name=AssociateId/>");
		out.println("First Name: <input type=text name=firstname/>");
		out.println("Last Name: <input type=text name=lastname/>");
		out.println("Department: <input type=text name=dept/>");
		out.println("Designation: <input type=text name=desig/>");
		out.println("Date of Birth:<input type=date name=dob>");
		*/
		out.println("username: <input type=text name=username placeholder=username/>");
		
		if(associateId.equals("123456"))
			out.print("AssociateId exists");
		
		
		
		out.println("password: <input type=password placeholder=password name=password/>");
		out.println("</form></body></html>");
	}

}
